const express = require('express');

const app = express();

const PORT = 3000;

const db = require('./config/db');
const heroRoutes = require('./routes/heroRoutes');

app.use(express.json());
app.use(heroRoutes);

app.get('/', (req, res) => {
  res.send('Hayyi Azzha');
});


app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

